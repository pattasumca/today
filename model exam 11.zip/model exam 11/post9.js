Exercise 9
models/user.js
const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true }
});

module.exports = mongoose.model('User', UserSchema);

routes/user.js
import express from 'express';
import { getAllUsers, login, logout, signUp } from "../controllers/user.js";
import { checkRole, checkToken } from '../middlewares/middlewares.js';
const router = express.Router();

router.post("/signUp", signUp);
router.post("/login", login);
router.post("/logout", checkToken, logout);
router.get('/getAllUsers', checkToken, checkRole(['admin', 'manager']), getAllUsers);

export default router;

Server.js
const express = require('express');
const connectDB = require('./config/db');
const cookieParser = require('cookie-parser');
const authRoutes = require('./routes/auth');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 2222;

app.use(express.json());
app.use(cookieParser());

app.use('/api/auth', authRoutes);

connectDB();
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

controller/user.js
import bcrypt from 'bcrypt';
import User from "../models/user.js";
import { CreateToken } from '../middlewares/middlewares.js';
import jsonwebtoken from 'jsonwebtoken';

export const signUp = async (req, res) => {

  const { name, mobile, email, password, role } = req.body;
  if (!name || !mobile || !email || !password) {
    return res.status(422).json({ message: "All feilds should be filled" })
  }
  try {
    let existingUser;
    try {
      existingUser = await User.findOne({ $or: [{ email: email }, { mobile: mobile }] });
    } catch (err) {
      console.error(err);
    }

    if (existingUser) {
      if (existingUser.email == email) {
        return res.status(409).json({ message: "A User is already signUp with this email" })
      }
      else if (existingUser.mobile == mobile) {
        return res.status(409).json({ message: "A User is already signUp with this mobile" })
      }
    }

    const salt = await bcrypt.genSalt(6)
    const hashedpassword = await bcrypt.hash(password, salt);

    const user = new User({
      name,
      mobile,
      email,
      password: hashedpassword,
      role: role,
    });

    await user.save();
    return res.status(201).json({ message: "Account Creation is success, Login to your account", User: user })

  } catch (err) {
    console.error(err)
    return res.status(400).json({ message: "Error in saving user in DB" });
  }

}

export const login = async (req, res) => {

  const { email, password } = req.body;
 
  if (!email || !password) {
    return res.status(422).json({ message: "All feilds should be filled" })
  }

  let loggedUser;

  try {
    loggedUser = await User.findOne({ email: email });

    if (!loggedUser) {
      return res.status(404).json({ message: "Email is not found, Check it and try again" })
    }
    const isPasswordCorrect = bcrypt.compareSync(password, loggedUser.password);
    if (!isPasswordCorrect) {
      return res.status(400).json({ message: "Invalid password, Check it and try again" })
    }
    const token = CreateToken(loggedUser._id);
      res.cookie(String(loggedUser._id), token, {
      path: "/",
      expires: new Date(Date.now() + 1000 * 59),
      httpOnly: true      sameSite: "lax"
    })

    return res.status(200).json({ message: "Successfully logged in", User: loggedUser })
  } catch (err) {
    console.log(err)
  }
}

export const logout = (req, res) => {
  const cookies = req.headers.cookie
  const previousToken = cookies.split("=")[1];

   if (!previousToken) {
    return res.status(400).json({ message: "Couldn't find token" });
  }
  jsonwebtoken.verify(String(previousToken), process.env.JWTAUTHSECRET, (err, user) => {
    if (err) {
      console.log(err);
      return res.status(403).json({ message: "Authentication failed" });    }
    res.clearCookie(`${user.id}`);
    req.cookies[`${user.id}`] = "";
    return res.status(200).json({ message: "Successfully Logged Out" });
  });
};

export const getAllUsers = async (req, res) => {
  try {
    const allusers = await User.find();
    if (!allusers) {
      return res.status(404).json({ message: "There are not any users" });
    }
    else {
      res.status(200).json({ allusers })
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Error in getting the Users" })
  }
}