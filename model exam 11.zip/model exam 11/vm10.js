📡 Method: Port Forwarding via NAT
Go to Settings → Network

Adapter 1:

Attached to: NAT

Click Advanced → Port Forwarding

Add a new rule:

Name: SSH

Protocol: TCP

Host Port: 2222

Guest Port: 22

This means when you SSH to localhost:2222, VirtualBox forwards it to the VM's port 22.


$ sudo systemctl status ssh

● ssh.service - OpenBSD Secure Shell server
     Loaded: loaded (/lib/systemd/system/ssh.service; enabled; vendor preset: enabled)
     Active: active (running) since Mon 2025-05-13 10:00:00 UTC; 1min ago


ssh student@localhost -p 2222


The authenticity of host '[localhost]:2222' can't be established.
ECDSA key fingerprint is SHA256:xxx...
Are you sure you want to continue connecting (yes/no)? yes
Warning: Permanently added '[localhost]:2222' (ECDSA) to the list of known hosts.
student@localhost's password: 
Welcome to Ubuntu 22.04.4 LTS (GNU/Linux 5.15.0-91-generic x86_64)

student@fswd-vm:~$

mkdir fswd_project
echo "<h1>Hello from FSWD VM</h1>" > fswd_project/index.html
cd fswd_project
python3 -m http.server 8080

Serving HTTP on 0.0.0.0 port 8080 (http://0.0.0.0:8080/) ...

    Then, on your host, open a browser and go to:

http://localhost:8080

You should see:

Hello from FSWD VM

sudo apt update
sudo apt install openssh-server
sudo systemctl status ssh

ssh username@localhost -p 2222

cd ~
mkdir fswd_project
echo "Hello from VM" > fswd_project/index.html
