Exercise 6.html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer CRUD App</title>
    <link rel="stylesheet" href="ex_6_style.css">
</head>
<body>
    <h2>Customer Management System</h2>
    <form id="customerForm">
        <input type="text" id="name" placeholder="Enter Name" required>
        <input type="text" id="city" placeholder="Enter City" required>
        <input type="text" id="mobile" placeholder="Enter Mobile No" required>
        <button type="submit">Add Customer</button>
    </form>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>City</th>
                <th>Mobile No</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="customersList"></tbody>
    </table>
    <script>
       const API_URL = 'http://localhost:5000/customers';
        async function fetchCustomers() {
            const res = await fetch(API_URL);
            const customers = await res.json();
            document.getElementById('customersList').innerHTML = customers.map(customer => `
                <tr>
                    <td><input type="text" value="${customer.name}" id="name-${customer.id}"></td>
                    <td><input type="text" value="${customer.city}" id="city-${customer.id}"></td>
                    <td><input type="text" value="${customer.mobile}" id="mobile-${customer.id}"></td>
                    <td>
                        <button onclick="updateCustomer('${customer.id}')">Update</button>
                        <button onclick="deleteCustomer('${customer.id}')">Delete</button>
                    </td>
                </tr>
            `).join('');
        }
        async function addCustomer(event) {
            event.preventDefault();
            const name = document.getElementById('name').value;
            const city = document.getElementById('city').value;
            const mobile = document.getElementById('mobile').value;
            await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, city, mobile })
            });
            document.getElementById('customerForm').reset();
            fetchCustomers();
        }
        async function updateCustomer(id) {
            const name = document.getElementById(`name-${id}`).value;
            const city = document.getElementById(`city-${id}`).value;
            const mobile = document.getElementById(`mobile-${id}`).value;
            await fetch(`${API_URL}/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, city, mobile })
            });
            fetchCustomers();
        }
        async function deleteCustomer(id) {
            await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
            fetchCustomers();
        }
        document.getElementById('customerForm').addEventListener('submit', addCustomer);
        fetchCustomers();
    </script>
</body>
</html>
Exercise 6 style.css
body {
    font-family: Arial, sans-serif;
    text-align: center;
    background-color: #f4f4f4;
}
form {
    margin: 20px auto;
    width: 50%;
    padding: 15px;
    background: white;
    border-radius: 8px;
}
input {
    padding: 10px;
    margin: 5px;
    width: 80%;
    border: 1px solid #ccc;
}
table {
    width: 60%;
    margin: 20px auto;
    border-collapse: collapse;
}
th, td {
    padding: 10px;
    border: 1px solid #ddd;
    text-align: center;
}
button {
    padding: 8px 12px;
    border: none;
    color: white;
    border-radius: 5px;
}
button:nth-child(1) { background-color: #28a745; }
button:nth-child(2) { background-color: #dc3545; }
Ex_6_server.js
require('dotenv').config();
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const app = express();
app.use(express.json());
app.use(cors());
const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME
});
db.connect(err => {
    if (err) {
        console.error("❌ MySQL Connection Error:", err.message);
        process.exit(1);
    }
    console.log('✅ MySQL Connected');
});
app.post('/customers', (req, res) => {
    const { name, city, mobile } = req.body;
    const sql = 'INSERT INTO customers (name, city, mobile) VALUES (?, ?, ?)';
    db.query(sql, [name, city, mobile], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ id: result.insertId, name, city, mobile });
    });
});
app.get('/customers', (req, res) => {
    const sql = 'SELECT * FROM customers';
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});
app.put('/customers/:id', (req, res) => {
    const { name, city, mobile } = req.body;
    const sql = 'UPDATE customers SET name = ?, city = ?, mobile = ? WHERE id = ?';
    db.query(sql, [name, city, mobile, req.params.id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Customer updated successfully' });
    });
});
app.delete('/customers/:id', (req, res) => {
    const sql = 'DELETE FROM customers WHERE id = ?';
    db.query(sql, [req.params.id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Customer deleted successfully' });
    });
});
app.listen(5000, () => console.log('🚀 Server running on port 5000'));

npm init-y
npm install express mysql2 cors dotenvnode 
node Ex_6_server.js

node_modeules
public
ex.htmlex.js
.env
pack-locak.json
package.json