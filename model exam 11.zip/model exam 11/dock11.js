Ex11_ server.js:
const http = require('http'); const hostname = '0.0.0.0'; const port = 8080;
const server = http.createServer((req, res) => {
if (req.method === 'GET' && req.url === '/ping') { res.statusCode = 200;
res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify({ message: 'pong' }));
} else {
res.statusCode = 404; res.end('Not Found');
}
});
server.listen(port, hostname, () => {
console.log(`Server running at http://${hostname}:${port}/`);
});
Dockerfile:
# Use official Node.js image from Docker Hub FROM node:16
# Set the working directory inside the container WORKDIR /usr/src/app
# Copy the server.js file to the working directory COPY server.js .
# Expose the port the app will run on EXPOSE 8080
# Run the Node.js server CMD ["node", "server.js"]

Output:
After running the server, you should be able to access the endpoint via http://localhost:8080/ping, and it should respond with the following JSON message: json
{
"message": "pong"
}