Exercise 8:
App.js
import React, { startTransition, useState } from 'react';
import './App.css';
function App() {
  const [todos, setTodos] = useState([]);
  const [input, setInput] = useState('');
  const [editIndex, setEditIndex] = useState(null);
  const [editText, setEditText] = useState('');
  const handleInputChange = (e) => {
    setInput(e.target.value);
  };
  const addTodo = () => {
    if (input.trim() !== '') {
      setTodos([...todos, { text: input, completed: false }]);
      setInput('');
    }
  };
  const toggleComplete = (index) => {
    const updatedTodos = todos.map((todo, i) =>
      i === index ? { ...todo, completed: !todo.completed } : todo
    );
    setTodos(updatedTodos);
  };
  const deleteTodo = (index) => {
    const updatedTodos = todos.filter((_, i) => i !== index);
    setTodos(updatedTodos);
  };
  const editTodo = (index) => {
  setEditIndex(index);
    setEditText(todos[index].text);
  };
  const saveEdit = () => {
    if (editText.trim() !== '') {
      const updatedTodos = todos.map((todo, i) =>
        i === editIndex ? { ...todo, text: editText } : todo
      );
      setTodos(updatedTodos);
      setEditIndex(null);
      setEditText('');
    }
  };
  return (
    <div className="App">
      <h1>To-Do App</h1>
      <div className="todo-input">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Enter a new task"
        />
        <button className="add-btn" onClick={addTodo}>Add</button>
      </div>
      {/* Edit todo */}
      {editIndex !== null && (
        <div className="edit-todo">
          <input
            type="text"
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
            placeholder="Edit your task"
          />
          <button className="save-btn" onClick={saveEdit}>Save</button>
        </div>
      )}
      <table className="todo-table">
        <thead>
          <tr>
            <th>Task</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {todos.map((todo, index) => (
            <tr key={index}>
              <td className={todo.completed ? 'completed' : ''}>
                <span onClick={() => toggleComplete(index)}>{todo.text}</span>
              </td>
              <td>
                <button className="edit-btn" onClick={() => editTodo(index)}>Edit</button>
                <button className="delete-btn" onClick={() => deleteTodo(index)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
export default App;

App.css
.App {
  text-align: center;
  margin-top: 20px;
  font-family: Arial, sans-serif;
}
.todo-input {
  margin-bottom: 20px;
}
input {
  padding: 10px;
  font-size: 16px;
  width: 250px;
}
button {
  padding: 10px;
  font-size: 16px;
  cursor: pointer;
  margin-left: 10px;
  border: none;
  border-radius: 4px;
}
.add-btn {
  background-color: green;
  color: white;
}
.add-btn:hover {
  background-color: darkgreen;
}
.delete-btn {
  background-color: red;
  color: white;
}
.delete-btn:hover {
  background-color: darkred;
}
.edit-btn {
  background-color: orange;
  color: white;
}
.edit-btn:hover {
  background-color: darkorange;
}
.todo-table {
  width: 80%;
  margin: 0 auto;
  border-collapse: collapse;
}
th, td {
  padding: 10px;
  text-align: left;
  border: 1px solid #ddd;
}
th {
  background-color: #f2f2f2;
}
.completed {
  text-decoration: line-through;
  color: gray;
}
.edit-todo {
  margin-top: 20px;
}
.edit-todo input {
  padding: 10px;
  font-size: 16px;
  width: 250px;
}
.save-btn {
  background-color: blue;
  color: white;
  cursor: pointer;
  padding: 10px;
  margin-left: 10px;
}
.save-btn:hover {
  background-color: darkblue;
}




terminal 1
npx create-react-app ex_8[folder name]
terminal2
npm install express fs body-parse cros
npm service.js
npm start

