Exercise 1.html
<html>  
<head>  
<script>  
function VALIDATEDETAIL()                                     
{  
var name = document.forms["RegForm"]["Name"];                
var email = document.forms["RegForm"]["EMail"];     
var phone = document.forms["RegForm"]["Telephone"];   
var what =  document.forms["RegForm"]["Subject"];   
var password = document.forms["RegForm"]["Password"];   
var address = document.forms["RegForm"]["Address"];   

    if (name.value == "")                                   
    {  
        window.alert("Please enter your name.");  
        name.focus();  
        return false;  
    }  
    
    if (address.value == "")                                
    {  
        window.alert("Please enter your address.");  
        name.focus();  
        return false;  
    }  
        
    if (email.value == "")                                    
    {  
        window.alert("Please enter a valid e-mail address.");  
        email.focus();  
        return false;  
    }  
    
    if (email.value.indexOf("@", 0) < 0) 
{  
        window.alert("Please enter a valid e-mail address.");  
        email.focus();  
        return false;  
    }  
    if (email.value.indexOf(".", 0) < 0)                  
    {  
        window.alert("Please enter a valid e-mail address.");  
        email.focus();  
        return false;  
    }  
    if (phone.value == "")                            
    {  
        window.alert("Please enter your telephone number.");  
        phone.focus();  
        return false;  
    }  
    if (password.value == "")                         
    {  
        window.alert("Please enter your password");  
        password.focus();  
        return flase;  
    }  
    
    if (what.selectedIndex < 1)                   
    {  
        alert("Please enter your course.");  
        what.focus();  
        return false;  
    }      
    return true;  
}</script> 

  <style>  
VALIDATEDETAIL {                                          
    font-weight: bold ;  
    float: left;  
    width: 100px;  
    text-align: left;  
    margin-right: 10px;  
    font-size:14px;  
}  
 div {  
box-sizing: border-box;  
    width: 100%;  
    border: 100px solid black;  
    float: left;  
    align-content: center;  
    align-items: center;  
}  
    
form {                                          
    margin: 0 auto;  
    width: 600px;  
}</style></head>  
    
<body>  
<h1 style="text-align: center"> REGISTRATION FORM </h1>            
<form name="RegForm" action="submit.php" onsubmit="return VALIDATEDETAIL()"  
method="post">   
       
    <p>Name: <input type="text" size=65 name="Name"> </p><br>         
    <p> Address: <input type="text" size=65 name="Address">  </p><br>  
    <p>E-mail Address: <input type="text" size=65 name="EMail">  </p><br>  
     <p>Password: <input type="text" size=65 name="Password"> </p><br>  
    <p>Telephone: <input type="text" size=65 name="Telephone"> </p><br>    
            
    <p>SELECT YOUR COURSE     
        <select type="text" value="" name="Subject">  
            <option>BTECH</option>  
            <option>BBA</option>  
            <option>BCA</option>  
            <option>B.COM</option>  
            <option>VALIDATEDETAIL</option>  
        </select></p><br><br>  
    <p>Comments:  <textarea cols="55" name="Comment">  </textarea></p>  
    <p><input type="submit" value="send" name="Submit">       
        <input type="reset" value="Reset" name="Reset">    


</p>           
</form>  
</body>  
</html>
Style.css
body {
  font-family: sans-serif;
  background-color: #f0f0f0; /* Light gray background */
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column; /* Stack elements vertically */
  align-items: center;
  min-height: 100vh;
}

h1 {
  text-align: center;
  color: #333; /* Dark gray title */
  margin-top: 20px;
  margin-bottom: 20px;
}

form {
  background-color: #fff; /* White form background */
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  width: 500px;
  max-width: 90%;
  margin-bottom: 20px; /* Space between form and buttons */
}

p {
  margin-bottom: 10px;
  color: #555;
}

input[type="text"],
select,
textarea {
  width: calc(100% - 22px);
  padding: 10px;
  margin-top: 5px;
  margin-bottom: 15px;
  border: 1px solid #ddd;
  border-radius: 4px;
  box-sizing: border-box;
}

select {
  height: 40px;
}

textarea {
  resize: vertical;
}

input[type="submit"],
input[type="reset"] {
  background-color: #007bff; /* Blue button */
  color: white;
  padding: 10px 15px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  margin-right: 10px;
}

input[type="submit"]:hover,
input[type="reset"]:hover {
  background-color: #0056b3; /* Darker blue on hover */
}

/* Optional: Style the button container for better alignment */
.button-container {
    display: flex;
    justify-content: center;
    width: 100%;
}



npx http-server