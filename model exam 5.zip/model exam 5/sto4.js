Exercise4.html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Submission</title>
</head>
<body>
    <h2>Submit Your Details</h2>
    <form action="/submit" method="post">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required><br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>

Ex_4_Server.js
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Middleware to parse form data
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Serve the HTML form (optional)
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

// Handle form submission
app.post('/submit', (req, res) => {
    const formData = req.body;

    // Read existing data
    let existingData = [];
    if (fs.existsSync('data.json')) {
        const fileContent = fs.readFileSync('data.json');
        existingData = JSON.parse(fileContent);
    }
    existingData.push(formData);
    fs.writeFileSync('data.json', JSON.stringify(existingData, null, 2));
    res.send('Form data saved successfully!');
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});

Data.json
[
  {
    "name": "Hulk",
    "email": "Hulk@gmail.com"
  },
  {
    "name": "Hulk",
    "email": "Hulk@gmail.com"
  }
]

npm init-y
npm install express
node ex4server.js

ex4.HTML
data.json
pakage_lock.json
package.json